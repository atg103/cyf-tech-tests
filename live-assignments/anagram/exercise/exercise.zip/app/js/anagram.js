function AnagramChecker () { }
AnagramChecker.prototype.checkAnagrams = function(word1, word2) {
	return undefined;
};
